#!/usr/bin/env python3

def main():
    print("Первая попытка запустить проект!")


if __name__ == "__main__":
    main()